Functioneaza atat chat_server cat si chat_echo.
Pentru a face conexiunea trebuie trimis cate un mesaj in ambele
terminale pentru client apoi totul functioneaza as intended.

Atat serverul cat si clinetii primesc IP-ul si PORT-ul ca param
in linia de comanda.